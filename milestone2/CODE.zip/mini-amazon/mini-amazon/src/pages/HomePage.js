import React from "react"

function HomePage() {
    return (
        <div className={"container"}>
            Welcome To Zest!
        </div>
    )
}

export default HomePage;