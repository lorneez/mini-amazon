# Team Members

Lorne Zhang (lrz150)

Jin Cho (jc695)

Brian Li (bl195)

Sophia Patterson (swp17)

Eric Young (ecy4)

# Project

Standard Project Option (Mini-Amazon) 

## Team Name

Zest

## Roles

Users Guru - Sophia Patterson

Products Guru - Brian Li

Carts Guru - Lorne Zhang

Sellers Guru - Eric Young

Social Guru - Jin Cho